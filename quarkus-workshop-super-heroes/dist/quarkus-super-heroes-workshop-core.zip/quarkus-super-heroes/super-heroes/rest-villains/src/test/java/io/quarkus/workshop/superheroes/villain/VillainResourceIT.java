package io.quarkus.workshop.superheroes.villain;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class VillainResourceIT extends VillainResourceTest {
    // Execute the same tests but in packaged mode.
}
